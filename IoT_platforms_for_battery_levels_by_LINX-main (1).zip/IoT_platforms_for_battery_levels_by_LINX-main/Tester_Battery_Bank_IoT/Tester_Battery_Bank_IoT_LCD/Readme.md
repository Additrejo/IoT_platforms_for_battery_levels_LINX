Armar el siguiente circuito y cargar el código.
[![Tester-battery-bank-iot-LCD.jpg](https://i.postimg.cc/zvZb0G2R/Tester-battery-bank-iot-LCD.jpg)](https://postimg.cc/S2dxKkhy)  
Dando como resultado:  
[![LCD.jpg](https://i.postimg.cc/6qZM7qgj/LCD.jpg)](https://postimg.cc/ctsR2xsw)
